import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      redirect: '/dashboard'
    },
    {
      path: '/',
      component: resolve => require(['../components/common/Home.vue'], resolve),
      meta: { title: '自述文件' },
      children:[
        {
          path: '/dashboard',
          component: resolve => require(['../components/page/Dashboard.vue'], resolve),
          meta: { title: '系统首页' }
        },
        {
          path: '/systemUser',
          component: resolve => require(['../components/page/SystemUser.vue'], resolve),
          meta: { title: '用户管理' }
        },
        {
          path: '/systemRole',
          component: resolve => require(['../components/page/SystemRole.vue'], resolve),
          meta: { title: '角色管理' }
        },
        {
          path: '/systemMenu',
          component: resolve => require(['../components/page/SystemMenu.vue'], resolve),
          meta: { title: '菜单管理' }
        },
        {
          path: '/systemDict',
          component: resolve => require(['../components/page/SystemDict.vue'], resolve),
          meta: { title: '字典管理' }
        },
        {
          path: '/systemMonitor',
          // component: resolve => require(['../components/page/Dashboard.vue'], resolve),
          meta: { title: '监控平台' },
          children:[
            {
              path: '/systemMonitor',
              component: resolve => require(['../components/page/SystemLog.vue'], resolve),
              meta: { title: '系统日志' },
            },
            // {
            //   path: '/systemMonitor',
            //   component: resolve => require(['../components/page/Dashboard.vue'], resolve),
            //   meta: { title: '数据库监测' },
            // }
          ]
        },
        {
          path: '/404',
          component: resolve => require(['../components/page/404.vue'], resolve),
          meta: { title: '404' }
        },
        {
          path: '/403',
          component: resolve => require(['../components/page/403.vue'], resolve),
          meta: { title: '403' }
        }
      ]
    },
    {
      path: '/login',
      component: resolve => require(['../components/page/Login.vue'], resolve)
    },
    {
      path: '*',
      redirect: '/404'
    }
  ]
})

var systemUser = {}

systemUser.column  = [
  { label: "用户名", prop: "orderCode",  operate: false },
  {
    label: "账户状态",
    prop: "payStatus",
    operate: false,
    //状态格式转换
    // formatter: (value, column) => {     //写上formatter函数
    //   // let payStatus = orderState(value, column);  //这里可以调用写好的函数也可以直接处理数据
    //   return payStatus;
    // }
  },
  {
    label: "注册时间",
    prop: "createTime",
    operate: false,
    //时间格式转换
    formatter: (value, column) => {
      let time = formDatetime(value, column);
      return time;
    },
  },
  {
    prop: "dealScreenshot",   //要与上面预留的slot位置一致
    label: "收款凭证",
    operate: true,
  }
]

systemUser.tableData  = [
  {
    orderCode: "1",
    payStatus: "1",
    createTime: new Date(),
  },
  {
    orderCode: "1",
    payStatus: "1",
    createTime: new Date(),
  },
  {
    orderCode: "1",
    payStatus: "1",
    createTime: new Date(),
  },
  {
    orderCode: "1",
    payStatus: "1",
    createTime: new Date(),
  },
  {
    orderCode: "1",
    payStatus: "1",
    createTime: new Date(),
  },
  {
    orderCode: "1",
    payStatus: "1",
    createTime: new Date(),
  },
  {
    orderCode: "1",
    payStatus: "1",
    createTime: new Date(),
  },
  {
    orderCode: "1",
    payStatus: "1",
    createTime: new Date(),
  },
  {
    orderCode: "1",
    payStatus: "1",
    createTime: new Date(),
  },
  {
    orderCode: "1",
    payStatus: "1",
    createTime: new Date(),
  },
]
import {formDatetime} from '../utils/formdata';
export {
  systemUser

}
